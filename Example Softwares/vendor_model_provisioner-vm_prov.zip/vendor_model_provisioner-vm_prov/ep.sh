#commander device masserase
commander device masserase --serialno 440045733

#commander flash GNU\ ARM\ v4.9.2\ -\ Default/*.hex
#commander flash GNU\ ARM\ v4.9.2\ -\ Default/*.hex --serialno 440060215
#commander flash GNU\ ARM\ v7.2.1\ -\ Default/*.hex
commander flash GNU\ ARM\ v7.2.1\ -\ Default/*.hex --serialno 440045733

#commander flash IAR\ ARM\ Default/*.hex
#commander flash IAR\ ARM\ Default/*.hex --serialno 440060215